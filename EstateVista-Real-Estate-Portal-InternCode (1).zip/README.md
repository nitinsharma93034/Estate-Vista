# EstateVista - Real Estate Portal
Web Development Intern Level Full-Featured Portal Codebase

## Features Included
1. **Property Listings**: Responsive Grid & List views with sorting and search.
2. **Filters Drawer**: Price range, beds, baths, sqft, property type, buy/rent, amenities.
3. **Contact Owner**: Direct inquiry form with tour appointment scheduler.
4. **Favorites**: LocalStorage backed bookmarks and side-by-side comparison modal.
5. **Admin Panel**: Listing manager (Add, Edit, Delete) & Inquiry status tracker.
6. **Code ZIP Exporter**: Self-contained client export.

## Quick Start
1. Extract the ZIP archive.
2. Run `npm install` to install dependencies.
3. Run `npm run dev` to start the Vite local development server on http://localhost:3000.
4. Run `npm run lint` or `npm run build` to test the project build.

Developed & verified for deployment ready production status.